USE [MobileStore_DB]
GO
SET IDENTITY_INSERT [dbo].[Brands] ON 
GO
INSERT [dbo].[Brands] ([ID], [Name]) VALUES (1, N'Apple')
GO
INSERT [dbo].[Brands] ([ID], [Name]) VALUES (2, N'Samsung')
GO
INSERT [dbo].[Brands] ([ID], [Name]) VALUES (3, N'VIVO')
GO
SET IDENTITY_INSERT [dbo].[Brands] OFF
GO
SET IDENTITY_INSERT [dbo].[Models] ON 
GO
INSERT [dbo].[Models] ([ID], [Name], [Brand_ID]) VALUES (1, N'I Phone 8', 1)
GO
INSERT [dbo].[Models] ([ID], [Name], [Brand_ID]) VALUES (2, N'I Phone 11', 1)
GO
INSERT [dbo].[Models] ([ID], [Name], [Brand_ID]) VALUES (3, N'M20', 2)
GO
INSERT [dbo].[Models] ([ID], [Name], [Brand_ID]) VALUES (4, N'M21', 2)
GO
INSERT [dbo].[Models] ([ID], [Name], [Brand_ID]) VALUES (5, N'J5', 2)
GO
SET IDENTITY_INSERT [dbo].[Models] OFF
GO
SET IDENTITY_INSERT [dbo].[AverageSalePrices] ON 
GO
INSERT [dbo].[AverageSalePrices] ([ID], [Model_ID], [AverageSellingPrice]) VALUES (1, 1, 60499)
GO
INSERT [dbo].[AverageSalePrices] ([ID], [Model_ID], [AverageSellingPrice]) VALUES (2, 5, 15090)
GO
INSERT [dbo].[AverageSalePrices] ([ID], [Model_ID], [AverageSellingPrice]) VALUES (3, 3, 11814)
GO
SET IDENTITY_INSERT [dbo].[AverageSalePrices] OFF
GO
SET IDENTITY_INSERT [dbo].[PurchaseDatas] ON 
GO
INSERT [dbo].[PurchaseDatas] ([ID], [Model_ID], [Date], [Quantity], [Price], [TotalAmount]) VALUES (1, 1, CAST(N'2021-10-16T00:00:00.000' AS DateTime), 5, 60000, 300000)
GO
INSERT [dbo].[PurchaseDatas] ([ID], [Model_ID], [Date], [Quantity], [Price], [TotalAmount]) VALUES (2, 1, CAST(N'2021-10-17T00:00:00.000' AS DateTime), 5, 62000, 310000)
GO
INSERT [dbo].[PurchaseDatas] ([ID], [Model_ID], [Date], [Quantity], [Price], [TotalAmount]) VALUES (3, 1, CAST(N'2021-10-18T00:00:00.000' AS DateTime), 5, 63000, 315000)
GO
INSERT [dbo].[PurchaseDatas] ([ID], [Model_ID], [Date], [Quantity], [Price], [TotalAmount]) VALUES (4, 1, CAST(N'2021-10-19T00:00:00.000' AS DateTime), 5, 57000, 285000)
GO
INSERT [dbo].[PurchaseDatas] ([ID], [Model_ID], [Date], [Quantity], [Price], [TotalAmount]) VALUES (5, 5, CAST(N'2021-10-14T00:00:00.000' AS DateTime), 10, 15500, 155000)
GO
INSERT [dbo].[PurchaseDatas] ([ID], [Model_ID], [Date], [Quantity], [Price], [TotalAmount]) VALUES (6, 5, CAST(N'2021-10-15T00:00:00.000' AS DateTime), 10, 15000, 150000)
GO
INSERT [dbo].[PurchaseDatas] ([ID], [Model_ID], [Date], [Quantity], [Price], [TotalAmount]) VALUES (7, 5, CAST(N'2021-10-15T00:00:00.000' AS DateTime), 35, 15000, 525000)
GO
INSERT [dbo].[PurchaseDatas] ([ID], [Model_ID], [Date], [Quantity], [Price], [TotalAmount]) VALUES (8, 3, CAST(N'2021-10-15T00:00:00.000' AS DateTime), 7, 12000, 84000)
GO
INSERT [dbo].[PurchaseDatas] ([ID], [Model_ID], [Date], [Quantity], [Price], [TotalAmount]) VALUES (9, 3, CAST(N'2021-10-15T00:00:00.000' AS DateTime), 9, 11670, 105030)
GO
SET IDENTITY_INSERT [dbo].[PurchaseDatas] OFF
GO
SET IDENTITY_INSERT [dbo].[SaleDetails] ON 
GO
INSERT [dbo].[SaleDetails] ([ID], [InvoiceNumber], [Date], [CustomerName], [CustomerContactNumber]) VALUES (1, N'2021_1', CAST(N'2021-10-16T00:00:00.000' AS DateTime), N'Abhinandan', N'9970932521')
GO
INSERT [dbo].[SaleDetails] ([ID], [InvoiceNumber], [Date], [CustomerName], [CustomerContactNumber]) VALUES (2, N'2021_2', CAST(N'2021-10-16T00:00:00.000' AS DateTime), N'Abhinandan', N'9970932521')
GO
INSERT [dbo].[SaleDetails] ([ID], [InvoiceNumber], [Date], [CustomerName], [CustomerContactNumber]) VALUES (3, N'2021_3', CAST(N'2021-10-16T00:00:00.000' AS DateTime), N'Abhinandan', N'9970932521')
GO
INSERT [dbo].[SaleDetails] ([ID], [InvoiceNumber], [Date], [CustomerName], [CustomerContactNumber]) VALUES (4, N'2021_4', CAST(N'2021-10-16T00:00:00.000' AS DateTime), N'Abhinandan', N'9970932521')
GO
INSERT [dbo].[SaleDetails] ([ID], [InvoiceNumber], [Date], [CustomerName], [CustomerContactNumber]) VALUES (5, N'2021_5', CAST(N'2021-10-16T00:00:00.000' AS DateTime), N'Abhinandan', N'9970932521')
GO
SET IDENTITY_INSERT [dbo].[SaleDetails] OFF
GO
SET IDENTITY_INSERT [dbo].[SaleItems] ON 
GO
INSERT [dbo].[SaleItems] ([ID], [Sales_ID], [Model_ID], [IMEI], [Quantity], [MRP], [Discount], [SellPrice]) VALUES (1, 1, 1, N'123456789', 1, 65000, 3000, 62000)
GO
INSERT [dbo].[SaleItems] ([ID], [Sales_ID], [Model_ID], [IMEI], [Quantity], [MRP], [Discount], [SellPrice]) VALUES (2, 2, 1, N'1234567877', 1, 65000, 2000, 63000)
GO
INSERT [dbo].[SaleItems] ([ID], [Sales_ID], [Model_ID], [IMEI], [Quantity], [MRP], [Discount], [SellPrice]) VALUES (3, 3, 1, N'1234567877', 1, 65000, 5000, 60000)
GO
INSERT [dbo].[SaleItems] ([ID], [Sales_ID], [Model_ID], [IMEI], [Quantity], [MRP], [Discount], [SellPrice]) VALUES (4, 4, 3, N'1122334455', 1, 13000, 1000, 12000)
GO
INSERT [dbo].[SaleItems] ([ID], [Sales_ID], [Model_ID], [IMEI], [Quantity], [MRP], [Discount], [SellPrice]) VALUES (5, 5, 5, N'88774455221', 1, 16000, 1200, 14800)
GO
SET IDENTITY_INSERT [dbo].[SaleItems] OFF
GO
SET IDENTITY_INSERT [dbo].[MStore_ApplicationException] ON 
GO
INSERT [dbo].[MStore_ApplicationException] ([ID], [Message], [Exception], [Inner_Exception], [Stack_Trace], [Namespace], [Class], [Method], [Created_On]) VALUES (1, N'An entity object cannot be referenced by multiple instances of IEntityChangeTracker.', N'System.InvalidOperationException: An entity object cannot be referenced by multiple instances of IEntityChangeTracker.
   at System.Data.Entity.Core.Objects.ObjectContext.VerifyContextForAddOrAttach(IEntityWrapper wrappedEntity)
   at System.Data.Entity.Core.Objects.ObjectContext.AttachSingleObject(IEntityWrapper wrappedEntity, EntitySet entitySet)
   at System.Data.Entity.Core.Objects.ObjectContext.AttachTo(String entitySetName, Object entity)
   at System.Data.Entity.Internal.Linq.InternalSet`1.<>c__DisplayClass16_0.<Attach>b__0()
   at System.Data.Entity.Internal.Linq.InternalSet`1.ActOnSet(Action action, EntityState newState, Object entity, String methodName)
   at System.Data.Entity.Internal.Linq.InternalSet`1.Attach(Object entity)
   at System.Data.Entity.DbSet`1.Attach(TEntity entity)
   at ExtraaEdge_Assignment.MStore.DAL.GenericRepository`2.UpdateAndGet(T entityToUpdate) in C:\My Documents\ExtraaEdge\Assignment\SourceCode\ExtraaEdge_Assignment\ExtraaEdge_Assignment.MStore.DAL\GenericRepository.cs:line 223
   at ExtraaEdge_Assignment.MStore.BAL.AverageSalePrice.update(AverageSalePrice existingRecord, Int32 price) in C:\My Documents\ExtraaEdge\Assignment\SourceCode\ExtraaEdge_Assignment\ExtraaEdge_Assignment.MStore.BAL\AverageSalePrice.cs:line 63', NULL, N'   at System.Data.Entity.Core.Objects.ObjectContext.VerifyContextForAddOrAttach(IEntityWrapper wrappedEntity)
   at System.Data.Entity.Core.Objects.ObjectContext.AttachSingleObject(IEntityWrapper wrappedEntity, EntitySet entitySet)
   at System.Data.Entity.Core.Objects.ObjectContext.AttachTo(String entitySetName, Object entity)
   at System.Data.Entity.Internal.Linq.InternalSet`1.<>c__DisplayClass16_0.<Attach>b__0()
   at System.Data.Entity.Internal.Linq.InternalSet`1.ActOnSet(Action action, EntityState newState, Object entity, String methodName)
   at System.Data.Entity.Internal.Linq.InternalSet`1.Attach(Object entity)
   at System.Data.Entity.DbSet`1.Attach(TEntity entity)
   at ExtraaEdge_Assignment.MStore.DAL.GenericRepository`2.UpdateAndGet(T entityToUpdate) in C:\My Documents\ExtraaEdge\Assignment\SourceCode\ExtraaEdge_Assignment\ExtraaEdge_Assignment.MStore.DAL\GenericRepository.cs:line 223
   at ExtraaEdge_Assignment.MStore.BAL.AverageSalePrice.update(AverageSalePrice existingRecord, Int32 price) in C:\My Documents\ExtraaEdge\Assignment\SourceCode\ExtraaEdge_Assignment\ExtraaEdge_Assignment.MStore.BAL\AverageSalePrice.cs:line 63', N'ExtraaEdge_Assignment.MStore.BAL', N'AverageSalePrice', N'update', CAST(N'2021-10-16T22:20:26.587' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[MStore_ApplicationException] OFF
GO
