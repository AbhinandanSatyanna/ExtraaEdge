﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BrandController : ControllerBase
    {
        [HttpGet("/api/GetBrands")]
        public dynamic Get()
        {
            return BAL.Brand.get();
        }

        [HttpPost("/api/AddBrand")]
        public dynamic Post(string name)
        {
            return BAL.Brand.insert(name);
        }
    }
}
