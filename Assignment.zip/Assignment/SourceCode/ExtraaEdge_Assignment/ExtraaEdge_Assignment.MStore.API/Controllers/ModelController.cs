﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ModelController : ControllerBase
    {
        [HttpGet("/api/GetModels")]
        public dynamic Get()
        {
            return BAL.Model.get(); 
        }

        [HttpPost("/api/AddModel")]
        public dynamic Post(string name, int brandID)
        {
            return BAL.Model.insert(name, brandID);
        }
    }
}
