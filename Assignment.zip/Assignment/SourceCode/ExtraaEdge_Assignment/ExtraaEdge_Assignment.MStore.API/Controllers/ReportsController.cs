﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportsController : ControllerBase
    {
        [HttpGet("/api/GetMonthlySalesReport")]
        public dynamic GetMonthlySalesReport(string fromDate, string toDate)
        {
            return BAL.Reports.MonthlySalesReport(fromDate, toDate);
        }

        [HttpGet("/api/GetMonthlyModelWiseSalesReport")]
        public dynamic GetMonthlyModelWiseSalesReport(int modelId, string fromDate, string toDate)
        {
            return BAL.Reports.MonthlyModelWiseSalesReport(modelId, fromDate, toDate);
        }

        [HttpGet("/api/GetMonthlyBrandWiseSalesReport")]
        public dynamic GetMonthlyBrandWiseSalesReport(int brandId, string fromDate, string toDate)
        {
            return BAL.Reports.MonthlyBrandWiseSalesReport(brandId, fromDate, toDate);
        }

        [HttpGet("/api/GetProfitAndLossReport")]
        public dynamic GetProfitAndLossReport(string fromDate, string toDate)
        {
            return BAL.Reports.ProfitAndLossReport(fromDate, toDate);
        }

        [HttpGet("/api/GetBestSellingPriceOfModel")]
        public dynamic GetBestSellingPriceOfModel(int modelId)
        {
            return BAL.AverageSalePrice.BestSellingPriceOfModel(modelId);
        }
    }
}
