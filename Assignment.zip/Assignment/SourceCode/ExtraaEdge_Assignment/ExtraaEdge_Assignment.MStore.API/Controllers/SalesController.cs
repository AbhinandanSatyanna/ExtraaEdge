﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SalesController : ControllerBase
    {
        [HttpPost("/api/AddSalesDetails")]
        public dynamic Post(BAL.Input.SalesData salesData)
        {
            return BAL.SaleDetails.insert(salesData);
        }
    }
}
