﻿using ExtraaEdge_Assignment.MStore.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL
{
    public class ApplicationException
    {
        public static Repository.MStoreApplication_MStore_ApplicationException _exception;
        public static void LogException(string namespaceName, string className, string methodName, Exception exception)
        {
            using (_exception = new Repository.MStoreApplication_MStore_ApplicationException(ApplicationSettings.connectionString))
            {
                _exception.Insert(new BO.MStore_ApplicationException()
                {
                    Class = className,
                    Created_On = DateTime.Now,
                    Exception = exception.ToString(),
                    Inner_Exception = exception.InnerException != null ? exception.InnerException.ToString() : null,
                    Message = exception.Message.ToString(),
                    Method = methodName,
                    Namespace = namespaceName,
                    Stack_Trace = exception.StackTrace.ToString()
                });
            }
        }
    }
}
