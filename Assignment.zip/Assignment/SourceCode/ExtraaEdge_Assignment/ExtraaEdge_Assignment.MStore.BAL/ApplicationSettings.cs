﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL
{
    public static class ApplicationSettings
    {
        public static string connectionString = string.Empty;
    }
}
