﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL
{
    public class AverageSalePrice
    {
        public static string updateAverageSalesPrice(int modelID, int new_price, int new_Quantity)
        {
            try
            {
                using (var _averageSalePrice = new Repository.MStoreApplication_AverageSalePrice(ApplicationSettings.connectionString))
                {
                    var existingRecord = _averageSalePrice.Get().Where(kk => kk.Model_ID.Equals(modelID)).FirstOrDefault();
                     
                    if (existingRecord == null)
                        return insert(modelID, new_price);
                    else
                    {
                        int total_existing_Purchased_Quantity = PurchaseDetails.getPurchasedQuantity(modelID) - new_Quantity;
                        int new_average_selling_price = ((total_existing_Purchased_Quantity * existingRecord.AverageSellingPrice) + (new_Quantity * new_price)) / (total_existing_Purchased_Quantity + new_Quantity);
                        return update(existingRecord, new_average_selling_price);
                    }
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<AverageSalePrice>(), Helper.GetClassName<AverageSalePrice>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }
        public static string insert(int modelID, int price)
        {
            try
            {
                using (var _averageSalePrice = new Repository.MStoreApplication_AverageSalePrice(ApplicationSettings.connectionString))
                {
                    var SalePrice = _averageSalePrice.InsertAndGet(new BO.AverageSalePrice()
                    {
                        Model_ID = modelID,
                        AverageSellingPrice = price
                    });
                    return "Average Sale price successfully added.";
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<AverageSalePrice>(), Helper.GetClassName<AverageSalePrice>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }
        public static string update(BO.AverageSalePrice existingRecord, int price)
        {
            try
            {
                using (var _averageSalePrice = new Repository.MStoreApplication_AverageSalePrice(ApplicationSettings.connectionString))
                {
                    BO.AverageSalePrice updatedDetails = new BO.AverageSalePrice()
                    {
                        ID = existingRecord.ID,
                        Model_ID = existingRecord.Model_ID,
                        AverageSellingPrice = price
                    };
                    var SalePrice = _averageSalePrice.UpdateAndGet(updatedDetails);
                    return "Average Sale price successfully updated.";
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<AverageSalePrice>(), Helper.GetClassName<AverageSalePrice>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }

        public static List<BO.AverageSalePrice> get()
        {
            try
            {
                using (var _averageSalePrice = new Repository.MStoreApplication_AverageSalePrice(ApplicationSettings.connectionString))
                {
                    return _averageSalePrice.GetAll().ToList();
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<AverageSalePrice>(), Helper.GetClassName<AverageSalePrice>(), Helper.GetCurrentMethod(), ex);
                return null;
            }
        }

        public static string BestSellingPriceOfModel(int modelID)
        {
            try
            {
                using (var _averageSalePrice = new Repository.MStoreApplication_AverageSalePrice(ApplicationSettings.connectionString))
                {
                    var existingRecord = _averageSalePrice.Get().Where(kk => kk.Model_ID.Equals(modelID)).FirstOrDefault();

                    return existingRecord != null ? string.Format("Best selling price of {0} is {1}", existingRecord.Model.Name, existingRecord.AverageSellingPrice.ToString())
                                                  : "This model is not available.";
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<AverageSalePrice>(), Helper.GetClassName<AverageSalePrice>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }
    }
}
