﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL
{
    public class Brand
    {
        public static dynamic get()
        {
            try
            {
                using (var _brand = new Repository.MStoreApplication_Brand(ApplicationSettings.connectionString))
                {
                    return _brand.GetAll().ToList();
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<Brand>(), Helper.GetClassName<Brand>(), Helper.GetCurrentMethod(), ex);
                return  "Exception : " + ex.Message;
            }
        }

        public static dynamic insert(string name)
        {
            try
            {
                using (var _brand = new Repository.MStoreApplication_Brand(ApplicationSettings.connectionString))
                {
                    if(_brand.GetAll().ToList().Any(kk=> kk.Name.Equals(name)))
                        return "Brand name is already available.";

                    _brand.Insert(new BO.Brand()
                    {
                        Name = name
                    });
                    return "Brand name successfully added.";
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<Brand>(), Helper.GetClassName<Brand>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }
    }
}
