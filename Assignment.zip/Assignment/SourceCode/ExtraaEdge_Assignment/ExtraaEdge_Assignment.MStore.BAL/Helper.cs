﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL
{
    public class Helper
    {
        /// <summary>
        /// Returung the method name, from where GetCurrentMethod is gettng called.
        /// </summary>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.NoInlining)]
        public static string GetCurrentMethod()
        {
            var st = new StackTrace();
            var sf = st.GetFrame(1);

            return sf.GetMethod().Name;
        }

        /// <summary>
        /// Returning Classname of given class
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static string GetClassName<T>()
        {
            return typeof(T).Name;
        }

        /// <summary>
        /// Returning Namespace of given class
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static string GetNamespaceName<T>()
        {
            return typeof(T).Namespace;
        }
    }
}
