﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL.Input
{
    public class PurchaseData
    {
        public DateTime Date { get; set; }
        public string VendorName { get; set; }
        public string VendorContactNumber { get; set; }
        public int ModelID { get; set; }
        public int Quantity { get; set; }
        public int Price { get; set; }
    }
}
