﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL.Input
{
    public class SalesData
    {
        public DateTime Date { get; set; }
        public string CustomerName { get; set; }
        public string CustomerContactNumber { get; set; }
        public List<SalesItemData> Items { get; set; }
    }
}
