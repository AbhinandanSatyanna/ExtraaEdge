﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL.Input
{
    public class SalesItemData
    {
        public int Model_ID { get; set; }
        public string Model { get; set; }
        public string IMEI { get; set; }
        public int Quantity { get; set; }
        public int MRP { get; set; }
        public int Discount { get; set; }
        public int SellPrice { get; set; }
    }
}
