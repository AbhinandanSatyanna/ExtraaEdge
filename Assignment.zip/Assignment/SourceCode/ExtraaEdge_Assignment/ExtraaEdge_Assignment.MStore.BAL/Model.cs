﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL
{
    public class Model
    {
        public static dynamic get()
        {
            try
            {
                using (var _Model = new Repository.MStoreApplication_Model(ApplicationSettings.connectionString))
                {
                    return _Model.GetAllIncluding(kk=> kk.Brand).ToList();
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<Brand>(), Helper.GetClassName<Brand>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }

        public static dynamic insert(string name, int brandID)
        {
            try
            {
                using (var _Model = new Repository.MStoreApplication_Model(ApplicationSettings.connectionString))
                {
                    if(_Model.GetAllIncluding(kk => kk.Brand).ToList().Any(kk=> kk.Brand_ID.Equals(brandID) && kk.Name.Equals(name)))
                        return "Model name is already available.";

                    _Model.Insert(new BO.Model()
                    {
                        Name = name,
                        Brand_ID = brandID
                    });
                    return "Model successfully added.";
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<Model>(), Helper.GetClassName<Model>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }
    }
}
