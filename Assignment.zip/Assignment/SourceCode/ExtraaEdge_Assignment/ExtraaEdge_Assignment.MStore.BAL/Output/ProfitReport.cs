﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL.Output
{
    public class ProfitReport
    {
        public string BrandName { get; set; }
        public string ModelName { get; set; }
        public int MRP { get; set; }
        public int SellPrice { get; set; }
        public int Discount { get; set; }
        public string Profit { get; set; }
        public DateTime Date { get; set; }
        public string CustomerName { get; set; }
        public string CustomerContactNumber { get; set; }
    }
}
