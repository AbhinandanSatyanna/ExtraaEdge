﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL
{
    public class PurchaseDetails
    {
        public static string insert(Input.PurchaseData purchaseData)
        {
            try
            {
                using (var _purchase = new Repository.MStoreApplication_PurchaseData(ApplicationSettings.connectionString))
                {
                    var purchaseDetails = _purchase.InsertAndGet(new BO.PurchaseData()
                    {
                       Date = purchaseData.Date,
                       Model_ID = purchaseData.ModelID,
                       Price = purchaseData.Price,
                       Quantity = purchaseData.Quantity,
                       TotalAmount = purchaseData.Quantity * purchaseData.Price
                    });
                    AverageSalePrice.updateAverageSalesPrice(purchaseData.ModelID, purchaseData.Price, purchaseData.Quantity);
                    return "Purchase data successfully added.";
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<PurchaseDetails>(), Helper.GetClassName<PurchaseDetails>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }

        public static int getPurchasedQuantity(int modelID)
        {
            try
            {
                using (var _purchase = new Repository.MStoreApplication_PurchaseData(ApplicationSettings.connectionString))
                {
                    return _purchase.GetAll().Where(kk=> kk.Model_ID.Equals(modelID)).Sum(kk=> kk.Quantity);
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<PurchaseDetails>(), Helper.GetClassName<PurchaseDetails>(), Helper.GetCurrentMethod(), ex);
                return 0;
            }
        }
    }
}
