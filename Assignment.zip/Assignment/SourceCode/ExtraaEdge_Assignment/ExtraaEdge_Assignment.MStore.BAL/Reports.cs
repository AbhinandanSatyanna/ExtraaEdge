﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL
{
    public class Reports
    {
        public static dynamic MonthlySalesReport(string fromDate, string toDate)
        {
            try
            {
                return getMonthlyReportData(0, 0, fromDate, toDate);
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<Reports>(), Helper.GetClassName<Reports>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }

        public static dynamic MonthlyModelWiseSalesReport(int modelId, string fromDate, string toDate)
        {
            try
            {
                return getMonthlyReportData(modelId, 0, fromDate, toDate);
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<Reports>(), Helper.GetClassName<Reports>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }

        public static dynamic MonthlyBrandWiseSalesReport(int brandId, string fromDate, string toDate)
        {
            try
            {
                return getMonthlyReportData(0, brandId, fromDate, toDate);
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<Reports>(), Helper.GetClassName<Reports>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }

        public static dynamic ProfitAndLossReport(string fromDate, string toDate)
        {
            try
            {
                List<BO.SaleItem> saleItems = new List<BO.SaleItem>();
                string result = SaleItems.getSalesData(0, 0, Convert.ToDateTime(fromDate), Convert.ToDateTime(toDate), ref saleItems);
                if (string.IsNullOrEmpty(result))
                    if (saleItems.Any())
                    {
                        var averageSellPrices = AverageSalePrice.get();
                        return saleItems.Select(kk => new Output.ProfitReport()
                        {
                            BrandName = kk.Model.Brand.Name,
                            ModelName = kk.Model.Name,
                            Date = kk.SaleDetails.Date,
                            MRP = kk.MRP,
                            SellPrice = kk.SellPrice,
                            Discount = kk.Discount,
                            CustomerName = kk.SaleDetails.CustomerName,
                            CustomerContactNumber = kk.SaleDetails.CustomerContactNumber,
                            Profit = (kk.SellPrice - averageSellPrices.Where(jj => jj.Model_ID.Equals(kk.Model_ID)).FirstOrDefault().AverageSellingPrice).ToString()
                        }).ToList();
                    }
                    else
                        return "Sales records not availale.";
                else
                    return result;
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<Reports>(), Helper.GetClassName<Reports>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }

        public static dynamic getMonthlyReportData(int modelId, int brandId, string fromDate, string toDate)
        {
            try
            {
                List<BO.SaleItem> saleItems = new List<BO.SaleItem>();
                string result = SaleItems.getSalesData(modelId, brandId, Convert.ToDateTime(fromDate), Convert.ToDateTime(toDate), ref saleItems);
                if (string.IsNullOrEmpty(result))
                    if (saleItems.Any())
                        return saleItems.Select(kk => new Output.SalesReport()
                        {
                            BrandName = kk.Model.Brand.Name,
                            ModelName = kk.Model.Name,
                            Date = kk.SaleDetails.Date,
                            MRP = kk.MRP,
                            SalePrice = kk.SellPrice,
                            Discount = kk.Discount,
                            CustomerName = kk.SaleDetails.CustomerName,
                            CustomerContactNumber = kk.SaleDetails.CustomerContactNumber
                        }).ToList();
                    else
                        return "Sales records not availale.";
                else
                    return result;
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<Reports>(), Helper.GetClassName<Reports>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }

    }
}
