﻿using ExtraaEdge_Assignment.MStore.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL.Repository
{
    public interface IMStoreApplication_MStore_ApplicationException : IGenericRepository<BO.MStore_ApplicationException> { }
    public interface IMStoreApplication_Brand : IGenericRepository<BO.Brand> { }
    public interface IMStoreApplication_Model : IGenericRepository<BO.Model> { }
    public interface IMStoreApplication_SaleDetails : IGenericRepository<BO.SaleDetails> { }
    public interface IMStoreApplication_SaleItem : IGenericRepository<BO.SaleItem> { }
    public interface IMStoreApplication_PurchaseData : IGenericRepository<BO.PurchaseData> { }
    public interface IMStoreApplication_AverageSalePrice : IGenericRepository<BO.AverageSalePrice> { }
}
