﻿using ExtraaEdge_Assignment.MStore.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL.Repository
{
    public class MStoreApplication_MStore_ApplicationException : GenericRepository<MStore_DataModel, BO.MStore_ApplicationException>, IMStoreApplication_MStore_ApplicationException
    {
        public MStoreApplication_MStore_ApplicationException(string connectionString) : base(new MStore_DataModel(connectionString)) { }
    }

    public class MStoreApplication_Brand : GenericRepository<MStore_DataModel, BO.Brand>, IMStoreApplication_Brand
    {
        public MStoreApplication_Brand(string connectionString) : base(new MStore_DataModel(connectionString)) { }
    }

    public class MStoreApplication_Model : GenericRepository<MStore_DataModel, BO.Model>, IMStoreApplication_Model
    {
        public MStoreApplication_Model(string connectionString) : base(new MStore_DataModel(connectionString)) { }
    }

    public class MStoreApplication_SaleDetails : GenericRepository<MStore_DataModel, BO.SaleDetails>, IMStoreApplication_SaleDetails
    {
        public MStoreApplication_SaleDetails(string connectionString) : base(new MStore_DataModel(connectionString)) { }
    }

    public class MStoreApplication_SaleItem : GenericRepository<MStore_DataModel, BO.SaleItem>, IMStoreApplication_SaleItem
    {
        public MStoreApplication_SaleItem(string connectionString) : base(new MStore_DataModel(connectionString)) { }
    }

    public class MStoreApplication_PurchaseData : GenericRepository<MStore_DataModel, BO.PurchaseData>, IMStoreApplication_PurchaseData
    {
        public MStoreApplication_PurchaseData(string connectionString) : base(new MStore_DataModel(connectionString)) { }
    }

    public class MStoreApplication_AverageSalePrice : GenericRepository<MStore_DataModel, BO.AverageSalePrice>, IMStoreApplication_AverageSalePrice
    {
        public MStoreApplication_AverageSalePrice(string connectionString) : base(new MStore_DataModel(connectionString)) { }
    }
}
