﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL
{
    public class SaleDetails
    {
        public static dynamic insert(Input.SalesData salesData)
        {
            try
            {
                using (var _sales = new Repository.MStoreApplication_SaleDetails(ApplicationSettings.connectionString))
                {
                    var salesDetails = _sales.InsertAndGet(new BO.SaleDetails()
                                        {
                                            InvoiceNumber = generateInvoiceNumber(),
                                            Date = salesData.Date,
                                            CustomerName = salesData.CustomerName,
                                            CustomerContactNumber = salesData.CustomerContactNumber
                                        });
                    SaleItems.insert(salesData.Items, salesDetails.ID);
                    return "Sales data successfully added.";
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<SaleDetails>(), Helper.GetClassName<SaleDetails>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }

        public static string generateInvoiceNumber()
        {
            try
            {
                using (var _sales = new Repository.MStoreApplication_SaleDetails(ApplicationSettings.connectionString))
                {
                    return String.Format("{0}_{1}", DateTime.Now.Year.ToString(), 
                                                                _sales.GetAll().Where(kk=> kk.InvoiceNumber.StartsWith(DateTime.Now.Year.ToString())).Count() + 1);
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<SaleDetails>(), Helper.GetClassName<SaleDetails>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }

    }
}
