﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BAL
{
    public class SaleItems
    {
        public static dynamic insert(List<Input.SalesItemData> salesItems, int salesID)
        {
            try
            {
                using (var _salesItem = new Repository.MStoreApplication_SaleItem(ApplicationSettings.connectionString))
                {
                    foreach(var item in salesItems)
                    {
                        _salesItem.Insert(new BO.SaleItem()
                        {
                            Sales_ID = salesID,
                            Model_ID = item.Model_ID,
                            Discount = item.Discount,
                            IMEI = item.IMEI,
                            MRP = item.MRP,
                            Quantity = item.Quantity,
                            SellPrice = item.SellPrice
                        });
                    }
                    return "Sales Item successfully added.";
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<SaleItems>(), Helper.GetClassName<SaleItems>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }

        public static string getSalesData(int modelID, int brandID, DateTime fromDate, DateTime toDate, ref List<BO.SaleItem> saleItems)
        {
            try
            {
                using (var _sales = new Repository.MStoreApplication_SaleItem(ApplicationSettings.connectionString))
                {
                    if(modelID == 0 && brandID == 0)
                        saleItems = _sales.GetAllIncluding(kk=> kk.SaleDetails, kk => kk.Model, kk => kk.Model.Brand)
                                            .Where(kk=> kk.SaleDetails.Date >= fromDate
                                                        && kk.SaleDetails.Date <= toDate)
                                            .ToList();
                    else if(brandID != 0)
                        saleItems = _sales.GetAllIncluding(kk => kk.SaleDetails, kk => kk.Model, kk => kk.Model.Brand)
                                            .Where(kk => kk.SaleDetails.Date >= fromDate
                                                        && kk.SaleDetails.Date <=  toDate
                                                        && kk.Model.Brand_ID.Equals(brandID))
                                            .ToList();
                    else
                        saleItems = _sales.GetAllIncluding(kk => kk.SaleDetails, kk => kk.Model, kk => kk.Model.Brand)
                                            .Where(kk => kk.SaleDetails.Date >=  fromDate
                                                        && kk.SaleDetails.Date <=  toDate
                                                        && kk.Model.ID.Equals(modelID))
                                            .ToList();
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                ApplicationException.LogException(Helper.GetNamespaceName<SaleItems>(), Helper.GetClassName<SaleItems>(), Helper.GetCurrentMethod(), ex);
                return "Exception : " + ex.Message;
            }
        }
    }
}
