﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BO
{
    public class MStore_ApplicationException
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }
        public string Message { get; set; }
        public string Exception { get; set; }
        public string Inner_Exception { get; set; }
        public string Stack_Trace { get; set; }

        [StringLength(200)]
        public string Namespace { get; set; }

        [StringLength(200)]
        public string Class { get; set; }

        [StringLength(200)]
        public string Method { get; set; }

        public DateTime? Created_On { get; set; }
    }
}
