﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.BO
{
    public class SaleItem
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }

        [Required]
        public int Sales_ID { get; set; }

        [ForeignKey("Sales_ID")]
        public virtual SaleDetails SaleDetails { get; set; }

        [Required]
        public int Model_ID { get; set; }

        [ForeignKey("Model_ID")]
        public virtual Model Model { get; set; }

        public string IMEI { get; set; }
        public int Quantity { get; set; }
        public int MRP { get; set; }
        public int Discount { get; set; }
        public int SellPrice { get; set; }
    }
}
