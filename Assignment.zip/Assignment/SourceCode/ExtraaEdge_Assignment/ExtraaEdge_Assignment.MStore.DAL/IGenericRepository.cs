﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.DAL
{
    public interface IGenericRepository<T> : IDisposable where T : class
    {
        IEnumerable<T> Get();
        T GetByID(object Id);
        void Insert(T entity);
        void Delete(object entityID);
        void Update(T entity);
        void Save();
    }
}
