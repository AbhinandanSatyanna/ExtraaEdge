﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraaEdge_Assignment.MStore.DAL
{
    public class MStore_DataModel : DbContext
    {
        public MStore_DataModel(string connectionString): base(connectionString)
        {
            Database.SetInitializer<MStore_DataModel>(new CreateDatabaseIfNotExists<MStore_DataModel>());
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
        }

        public DbSet<BO.Brand> BrandsEn { get; set; }
        public DbSet<BO.Model> ModelsEn { get; set; }
        public DbSet<BO.SaleDetails> SaleDetailsEn { get; set; }
        public DbSet<BO.SaleItem> SaleItemsEn { get; set; }
        public DbSet<BO.PurchaseData> PurchaseDatasEn { get; set; }
        public DbSet<BO.AverageSalePrice> AverageSalePricesEn { get; set; }
        public DbSet<BO.MStore_ApplicationException> MStore_ApplicationExceptionsEn { get; set; }
    }
}
